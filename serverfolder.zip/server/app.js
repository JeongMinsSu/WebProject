const express = require('express')
const app = express()
const cors = require('cors')

app.use(cors());
app.use(express.json()); // for parsing application/json
app.use(express.urlencoded({ extended: true})); //for parsing


//todoList => post1 
// post 2
// post 3

const post3 = [];


app.get('/api/todo3',(req, res) => {
    res.json(post3);
})
app.post('/api/todo3',(req, res) => {
    const { title3,username3,content3} = req.body;
    const currentDate = new Date();

    console.log('req.body:',req.body);
    post3.push({
        title3,
        username3,
        content3,
        year: currentDate.getFullYear(),
        month: currentDate.getMonth()+1,
        day: currentDate.getDate(),
    })
    return res.send('success');
})

const post2 = [];

app.get('/api/todo2',(req, res) => {
    res.json(post2);
})
app.post('/api/todo2',(req, res) => {
    const {title2,username2,content2} = req.body;
    const currentDate = new Date();

    console.log('req.body:',req.body);
    post2.push({
        title2,
        username2,
        content2,
        year: currentDate.getFullYear(),
        month: currentDate.getMonth()+1,
        day: currentDate.getDate(),
    })
    return res.send('success');
})

const todoList = [ ];


app.get('/api/todo',(req, res) => {
    res.json(todoList);
})
app.post('/api/todo',(req, res) => {
    const {title,username,content} = req.body;
    const currentDate = new Date();

    console.log('req.body:',req.body);
    todoList.push({
        title,
        username ,
        content,
        year: currentDate.getFullYear(),
        month: currentDate.getMonth()+1,
        day: currentDate.getDate(),
        
    })
    
    return res.send('success');
    
})


app.listen(3001, () => {
    console.log('server please start')
})