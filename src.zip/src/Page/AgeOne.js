import { Route, useParams } from "react-router-dom";
import "./page.css";
import "../PostList.css";
import { BrowserRouter as Router, Link } from "react-router-dom";
import Writing from "../Writing.js";
// import { BrowserRouter as Router, Link } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";
// import search from '../Search.js'

//페이지네이션 구현 내용--------------------------------------------------------------------------

function PaginationComponent({ postsPerPage, totalPosts, paginate }) {
  const pageNumbers = [];

  for (let i = 1; i <= Math.ceil(totalPosts / postsPerPage); i++) {
    pageNumbers.push(i);
  }

  return (
    <div>
      {pageNumbers.map((number) => (
        <button key={number} onClick={() => paginate(number)}>
          {number}
        </button>
      ))}
    </div>
  );
}

//------------------------------------------------------------------------

const AgeOne = () => {
  // const { category } = useParams();
  const [todoList, setTodoList] = useState([]);

  const fetchData = async () => {
    const response = await axios.get("http://localhost:3001/api/todo");
    setTodoList(response.data);
  };

  useEffect(() => {
    fetchData();
  }, []);
  //   useEffect(() => {
  //     // 데이터를 불러오는 비동기 함수
  //     const apiUrl = 'http://localhost:3001/api/todo';

  //     axios.get(apiUrl).then(response => {
  //       setDataList(response.dataList);
  //     })
  //     .catch(error => {
  //       console.error('Error fetching data:',error);
  //     });
  // }, []); // 빈 배열을 전달하여 한 번만 실행되도록 함

  //

  const [showComponent, setShowComponent] = useState(false);
  const showWrite = () => {
    //글쓰기 페이지를 보이게 하기
    // state 값을 true로 바꾼다 클릭 될때 마다 T -> F -> T

    setShowComponent(!showComponent);

    // 글쓰기 한번 클릭 됐을 때 작동 안되게 하기
  };

  // 페이지네이션관련코드 -----------------
  const reversedPosts = [...todoList].reverse();
  const postsPerPage = 10; // 페이지당 보여질 게시물 수
  const [currentPage, setCurrentPage] = useState(1);

  // 현재 페이지의 게시물 계산
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = reversedPosts.slice(indexOfFirstPost, indexOfLastPost);

  // 페이지 변경 핸들러
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  //------------------------------------------- 페이지네이션관련코드

  return (
    <div className="center">
      <div className='Titles'>
        <Link to="/" style={{ textDecoration: "none" }}>짠돌이 커뮤니티</Link>
        {/* 검색 */}
        {/* <Search className='search'/> */}
       
        {/* 찾을 내용 검색 박스 */}
       
      </div>
      <h2>10대 게시판</h2>
      <hr />
      <div className="tableContainer">
        <table className="tableCss">
          <colgroup>
            <col width="15%" />
            <col width="65%" />
            <col width="*%" />
            <col width="*%" />
          </colgroup>

          <thead>
            <tr>
              <th className="backColor">글번호</th>
              <th className="backColor">제목</th>
              <th className="backColor">작성일</th>
              <th className="backColor">작성자</th>
            </tr>
          </thead>
          <tbody>
            {currentPosts.map((todo, index) => (
              <tr className="thHeight" key={todo.id}>
                <td>{reversedPosts.length - index}</td>
                <td>
                  <Link to={`/post/${todo.title}`}>{todo.title}</Link>
                  {/* {todo.title} */}
                </td>
                <td>
                  {todo.year}-{todo.month}-{todo.day}
                </td>
                <td>{todo.username}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <br />
      <br />

      <div className="paginationContainer">
        <PaginationComponent
          postsPerPage={postsPerPage}
          totalPosts={reversedPosts.length}
          paginate={paginate}
        />
      </div>
      <div className="buttonContainer">
          <button onClick={showWrite}> 글 쓰기 </button>
        </div>
        <br />

        {showComponent && <Writing />}
    </div>
  );
};

export default AgeOne;
