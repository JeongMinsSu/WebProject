import "./page.css";
import "../PostList.css";
import { BrowserRouter as Router ,Link } from "react-router-dom";
import Writing from "../Writing.js";
import { useState, useEffect } from "react";
import axios from "axios";

//페이지네이션 구현 내용--------------------------------------------------------------------------

function PaginationComponent({ postsPerPage, totalPosts, paginate }) {
  const pageNumbers = [];

  for (let i = 1; i <= Math.ceil(totalPosts / postsPerPage); i++) {
    pageNumbers.push(i);
  }

  return (
    <div>
      {pageNumbers.map((number) => (
        <button key={number} onClick={() => paginate(number)}>
          {number}
        </button>
      ))}
    </div>
  );
}

//------------------------------------------------------------------------

const AgeOne = () => {
  const [todoList, setTodoList] = useState([]);

  const fetchData = async () => {
    const response = await axios.get("http://localhost:3001/api/todo");
    setTodoList(response.data);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const [showComponent, setShowComponent] = useState(false);
  const showWrite = () => {
    setShowComponent(!showComponent);
  };

  // 페이지네이션관련코드 -----------------

  const reversedPosts = [...todoList].reverse();
  const postsPerPage = 10; 
  const [currentPage, setCurrentPage] = useState(1);
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = reversedPosts.slice(indexOfFirstPost, indexOfLastPost);
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  //------------------------------------------- 페이지네이션관련코드

  return (
    <div className="center">
      <div className='Titles'>
        <Link to="/" style={{ textDecoration: "none" }}>짠돌이 커뮤니티</Link>
      </div>
      <h2>10대 게시판</h2>
      <hr />
      <div className="tableContainer">
        <table className="tableCss">
          <colgroup>
            <col width="15%" />
            <col width="65%" />
            <col width="*%" />
            <col width="*%" />
          </colgroup>
          <thead>
            <tr>
              <th className="backColor">글번호</th>
              <th className="backColor">제목</th>
              <th className="backColor">작성일</th>
              <th className="backColor">작성자</th>
            </tr>
          </thead>
          <tbody>
            {currentPosts.map((todo, index) => (
              <tr className="thHeight" key={todo.id}>
                <td>{reversedPosts.length - index}</td>
                <td>
                  <Link to={`/post/${todo.title}`}>{todo.title}</Link>
                </td>
                <td>
                  {todo.year}-{todo.month}-{todo.day}
                </td>
                <td>{todo.username}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <br />
      <br />
      <div className="paginationContainer">
        <PaginationComponent
          postsPerPage={postsPerPage}
          totalPosts={reversedPosts.length}
          paginate={paginate}
        />
      </div>
      <div className="buttonContainer">
          <button onClick={showWrite}> 글 쓰기 </button>
      </div>
      <br />
      {showComponent && <Writing />}
    </div>
  );
};

export default AgeOne;
