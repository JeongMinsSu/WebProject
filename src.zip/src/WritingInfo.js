import { BrowserRouter as  Link } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './App.css';
import './postInfo.css'

function WritingInfo() {
  const [loading,setLoading] = useState({});
  const [post,setPost] = useState({});
  const getPost = async () => {
    const resp = await axios.get("http://localhost:3001/api/todo");
    setPost(resp.data);
    setLoading(false);

  };
  useEffect(()=> {
    getPost();
  },[]);

  const {title} = useParams();
  const currentPost = Array.isArray(post) && post.find((item) => item.title === title);
  return (
    <div className='background'>
      {loading ? (
        <h1>Loading...</h1>
      ):(
        <div className='section'>
          {currentPost && (
          <div className='inside'key={currentPost.id}>
            <h2>제목: {currentPost.title}</h2>
            <hr></hr>
            <h4>작성자: {currentPost.username}</h4>  
            <p> 내용: {currentPost.content}</p>
          <div className='backTo'>
            <Link to='/'><input type='button' value='돌아가기'/></Link>
          </div>
        </div>
    )}
        </div>
      )}

    </div>
    
    );
  }

export default WritingInfo;