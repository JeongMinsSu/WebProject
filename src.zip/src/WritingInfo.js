import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import Post from './Post.js';
import './App.css';
import './postInfo.css'

function WritingInfo() {
  // const [selectedPostId, setSelectedPostId] = useState(null);
  // const {Title} = useParams();
  const [loading,setLoading] = useState({});
  const [post,setPost] = useState({});
  const getPost = async () => {
    const resp = await axios.get("http://localhost:3001/api/todo");
    setPost(resp.data);
    setLoading(false);

  };
  useEffect(()=> {
    getPost();
  },[]);
  
  
// const selectedPost = post.find((todo)=> );

  const {title} = useParams();
  const currentPost = Array.isArray(post) && post.find((item) => item.title === title);
  return (
    <div className='background'>
      {loading ? (
        <h1>Loading...</h1>
      ):(

        <div className='section'>
          {currentPost && (
          <div className='inside'key={currentPost.id}>
            <h2>제목: {currentPost.title}</h2>
            <hr></hr>
            <h4>작성자: {currentPost.username}</h4>  
            <p> 내용: {currentPost.content}</p>
          <div className='backTo'>
            <Link to='/'><input type='button' value='돌아가기'/></Link>
          </div>
        </div>
    )}
        
        </div>
        
        
        
      )}

    </div>
    // <Router>
    //   <div className="App">
    //     <BoardHead />
    //     <Routes>
    //       <Route path="/" element={<BoardNav setSelectedPostId={setSelectedPostId} />} />
    //       <Route path="/post/:id" element={<Post />} />
    //     </Routes>
    //     <BoardBox />
    //   </div>
    // </Router>
    
    
    
    
    );
  }
// function BoardHead() {
//   return (
//     <div className='board-head'>
//       <div>웹 응용 프로그래밍</div>
//     </div>
//   );
// }

// function BoardNav({ setSelectedPostId }) {
//   return (
//     <div className='board-nav'>
//       <div onClick={() => setSelectedPostId(1)}><Link to="/post/1">게시글 1</Link></div>
//       <div onClick={() => setSelectedPostId(2)}><Link to="/post/2">게시글 2</Link></div>
//       <div onClick={() => setSelectedPostId(3)}><Link to="/post/3">게시글 3</Link></div>
//       <div onClick={() => setSelectedPostId(4)}><Link to="/post/4">게시글 4</Link></div>
//       <div onClick={() => setSelectedPostId(5)}><Link to="/post/5">게시글 5</Link></div>
//     </div>
//   );
// }

// function Post({ match }) {
//   const id = match.params.id;
//   const [title, setTitle] = useState('');
//   const [content, setContent] = useState('');

//   fetch(`./sample-data/posts/${id}.json`, {
//     headers: {
//       'Content-Type': 'application/json',
//       'Accept': 'application/json'
//     }
//   })
//     .then((res) => res.json())
//     .then((json) => {
//       setTitle(json.title);
//       setContent(json.content);
//     });

//   return (
//     <div>
//       <h1>{title}</h1>
//       <p>{content}</p>
//       <div><Link to="/">돌아가기</Link></div>
//     </div>
//   );
// }

// function BoardBox() {
//   return (
//     <div className='board-box'>
//       {/* BoardBox 컴포넌트 내용 */}
//     </div>
//   );
// }
  

export default WritingInfo;