import React, { useEffect } from 'react'
import { Link } from 'react-router-dom';
import './MainPage.css';
import Search from './Search';
import { useState } from 'react';
import axios from 'axios';
import Youtube from './Youtube';

const MainPage = () => {
  
  const [todoList, setTodoList] = useState([]);
  const [post2, setpost2List] = useState([]);
  const [post3, setpost3List] = useState([]);
  

  const fetchData = async () => {
    const response = await axios.get('http://localhost:3001/api/todo');
    setTodoList(response.data);
  }

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData2 = async () => {
    const response = await axios.get('http://localhost:3001/api/todo2');
    setpost2List(response.data);
  }

  useEffect(() => {
    fetchData2();
  }, []);

  const fetchData3 = async () => {
    const response = await axios.get('http://localhost:3001/api/todo3');
    setpost3List(response.data);
  }

  useEffect(() => {
    fetchData3();
  }, []);

  return (
    <div>
      <div className='Titles'>
        <Link to="/" style={{ textDecoration: "none" }}>짠돌이 커뮤니티</Link>
        <Search className='search'/>
      </div>

      <div className='agecomunuty'>
        <div className='ten'>
          <Link to="/AgeOne/10age" style={{ textDecoration: "none" }}>10대</Link>
        </div>

        <div className='twenty'>
          <Link to="/AgeTwo/20age" style={{ textDecoration: "none" }}>20대</Link>
        </div>

        <div className='thirty'>
          <Link to="/AgeThree/30age" style={{ textDecoration: "none" }}>30대</Link>
        </div>
      </div>
    
      <div className='category'>
        <div className='One'>
          <ol>
            <div>
            {todoList.map((post) => (
              <li key={post.id}>
                <Link style={{textDecoration:"none"}}to={`/post/${post.title}`}>{post.title}</Link>
              </li>
            ))}
            
            </div>
          </ol>
        </div>
        <div className='Two'>
          <ol>
            <div>
            {post2.map((post) => (
              <li key={post.id}>
                <Link style={{textDecoration:"none"}} to={`/post2/${post.title2}`}>{post.title2}</Link>
        
              </li>
            ))}
            
            </div>
          </ol>
        </div>
        <div className='Three'>
          <ol>
            <div>
            {post3.map((post) => (
              <li key={post.id}>
                <Link  style={{textDecoration:"none"}} to={`/post3/${post.title3}`}>{post.title3}</Link>
              </li>
            ))}
            </div>
          </ol>
        </div>
      </div>
      <hr/>
      <div className='movie'>
        <div className='movie_wrapper'>
          <Youtube/>
        </div>
      </div>
    </div>
  );
}

export default MainPage;