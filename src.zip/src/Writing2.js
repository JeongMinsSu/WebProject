import React from 'react';
import { useState } from 'react';
import axios from 'axios';


const Writing2 = () => {
    const [isVisible,setIsVisible] = useState(true);
    const handleCancle = () => {
        setIsVisible((Visible => !Visible));
    };

    const saveBoard = async(e)=>{
        const title2 = e.target.title.value;
        const username2 = e.target.username.value;
        const content2 = e.target.content.value;
        
        await axios.post('http://localhost:3001/api/todo2', {title2,username2,content2
    });
        saveBoard();
        alert ('등록 완료');    
    }
    
    return isVisible ?(
        <div className="Writing_Compo">
            <main className='Main'>
                <form onSubmit={saveBoard}>
                    <div className='mini_title'>
                        <label for="title">제목: </label>
                        <input className='title_name' name='title' type='text'/>
                    </div>
                    <div className='writer'>
                        <label for="title">작성자: </label>
                        <input className='date' name='username' type='text'/>
                    </div>
                    <article>
                        <textarea className='Main_content'type='text'name='content'/>
                    </article>
                    <section>
                        <div>
                            <input type='submit' value="등록"/>
                            <button onClick={handleCancle}>취소</button>
                        </div>
                    </section>
                </form>
                
            </main>
        </div>
    ) : null ;
}

export default Writing2;