import { BrowserRouter as Link } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './App.css';

function WritingInfo2() {
  const [loading,setLoading] = useState({});
  const [post2,setPost2] = useState({});
  const getPost2 = async () => {
    const resp = await axios.get("http://localhost:3001/api/todo2");
    setPost2(resp.data);
    setLoading(false);
  };
  useEffect(()=> {
    getPost2();
  },[]);
  
  const {title2} = useParams();
  const currentPost = Array.isArray(post2) && post2.find((item) => item.title2 === title2);
  return (
    <div className='background'>
      {loading ? (
        <h1>Loading...</h1>
      ):(

        <div className='section'>
          {currentPost && (
          <div className='inside'key={currentPost.id}>
            <h2>제목: {currentPost.title2}</h2>
            <hr></hr>
            <h4>작성자: {currentPost.username2}</h4>  
            <p> 내용: {currentPost.content2}</p>
          <div className='backTo'>
            <Link to='/'><input type='button' value='돌아가기'/></Link>
          </div>
        </div>
    )}
        
        </div>
        
        
        
      )}

    </div>
    );
}

export default WritingInfo2;