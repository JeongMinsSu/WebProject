import React from 'react';
import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Writing3 = () => {
    const [isVisible,setIsVisible] = useState(true);
    const handleCancle = () => {
        setIsVisible((prevIsVisible => !prevIsVisible));
    };

//어디 카테고리에 있는지 어떻게 알수 있는가??

    const saveBoard = async(e)=>{
        const title3 = e.target.title.value;
        const username3 = e.target.username.value;
        const content3 = e.target.content.value;
        
        await axios.post('http://localhost:3001/api/todo3', {title3,username3,content3
    });
        saveBoard();
        alert ('등록 완료');    
    }
    
// name을 키값, value를 내용으로 가져온다
    
    // onchange={handleChangeTitle}함수 변화가 오면 계속 변함

    // 이미지 넣기
    // const [image, setImage] = useState(null);
    
    // const handleImageChange = (e) => {
    //     const selectedImage = e.target.files[0];
        
    //     if(selectedImage){
    //         const reader = new FileReader();

    //         reader.onload = (readerEvent) => {
    //             setImage(readerEvent.target.result);
    //         };
    //         reader.readAsDataURL(selectedImage);
    //     }
    // }
    // 취소했을때 컴포넌트 안보이게 바꾸기
    
    return isVisible ?(
        <div className="Writing_Compo">
            
            <main className='Main'>
                <form onSubmit={saveBoard}>
                    {/* <input type="file" value="" onChange={handleImageChange} />
                    {image && <img src={image} alt="이미지" style={{ width: '100px', height: '100px' }} />} */}
                    
                    <div className='mini_title'>
                        <label for="title">제목: </label>
                        <input className='title_name' name='title' type='text'/>
                    </div>
                    <div className='writer'>
                        <label for="title">작성자: </label>
                        <input className='date' name='username' type='text'/>
                    </div>
                    <article>
                        <textarea className='Main_content'type='text'name='content'/>
                    </article>
                    <section>
                        <div>
                            {/* 제목,날짜 등 input 컴포넌트의 name 을 가져와서 saveBoard로 post해서 값을 추가  */}
                            {/* form 안에 post 요청을 보낼때 query 파라미터로 한번 보내버리기 때문에 e.prevent를 실행해야함 */}
                            <input type='submit' value="등록"/>
                            <button onClick={handleCancle}>취소</button>
                        </div>
                    </section>
                </form>
                
            </main>
        </div>
    ) : null ;
}

export default Writing3;