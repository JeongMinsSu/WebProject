import React from 'react';
import { useState } from 'react';
import axios from 'axios';


const Writing3 = () => {
    const [isVisible,setIsVisible] = useState(true);
    const handleCancle = () => {
        setIsVisible((Visible => !Visible));
    };

    const saveBoard = async(e)=>{
        const title3 = e.target.title.value;
        const username3 = e.target.username.value;
        const content3 = e.target.content.value;
        
        await axios.post('http://localhost:3001/api/todo3', {title3,username3,content3
    });
        saveBoard();
        alert ('등록 완료');    
    }
    
    return isVisible ?(
        <div className="Writing_Compo">
            
            <main className='Main'>
                <form onSubmit={saveBoard}>
                    <div className='mini_title'>
                        <label for="title">제목: </label>
                        <input className='title_name' name='title' type='text'/>
                    </div>
                    <div className='writer'>
                        <label for="title">작성자: </label>
                        <input className='date' name='username' type='text'/>
                    </div>
                    <article>
                        <textarea className='Main_content'type='text'name='content'/>
                    </article>
                    <section>
                        <div>
                            <input type='submit' value="등록"/>
                            <button onClick={handleCancle}>취소</button>
                        </div>
                    </section>
                </form>
                
            </main>
        </div>
    ) : null ;
}

export default Writing3;