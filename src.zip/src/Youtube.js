//하단 영상 재생
import React, { useState, useEffect } from 'react';
import YouTube from 'react-youtube';

function App() {
  const [videoId, setVideoId] = useState('');

  // 유튜브 영상 ID들의 배열
  const videoIds = ['-jVtu7N-Z7A',
                    'BWJ_Swb5xZE',
                    '9OPN2Y1YmKw', 
                    'YY9VUjVSdRU', 
                    'P459IWhWlv4',
                    'cBj26HYkT7E',
                    'kRaeVuXfrx8',
                    'QydhseVEyns',
                    '40TCg7o-KpI',
                    'cfRmxlQJrgA',
                    'kMUb9NLZ1Q8',
                    'M6F8E2fh0Fs',
                    'eHpwsRb3QUM',
                    'kupAFpSuwmY',
                    'R5_n5HsgnRU',
                ];

  useEffect(() => {
    // 배열에서 랜덤하게 하나의 ID를 선택
    const randomVideoId = videoIds[Math.floor(Math.random() * videoIds.length)];
    setVideoId(randomVideoId);
  }, []);

  return (
    <div className="App">
      <YouTube className='video'videoId={videoId} />
      <YouTube className='video'videoId={videoId} />
      <YouTube className='video'videoId={videoId} />
      <YouTube className='video'videoId={videoId} />
    </div>
  );
}

export default App;