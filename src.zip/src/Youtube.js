import React, { useState, useEffect } from 'react';
import YouTube from 'react-youtube';

function App() {
  const [videoId, setVideoId] = useState('');

  const videoIds = ['-jVtu7N-Z7A',
                    'BWJ_Swb5xZE',
                    '9OPN2Y1YmKw', 
                    'YY9VUjVSdRU', 
                    'P459IWhWlv4',
                    'cBj26HYkT7E',
                    'kRaeVuXfrx8',
                    'QydhseVEyns',
                    '40TCg7o-KpI',
                    'cfRmxlQJrgA',
                    'kMUb9NLZ1Q8',
                    'M6F8E2fh0Fs',
                    'eHpwsRb3QUM',
                    'kupAFpSuwmY',
                    'R5_n5HsgnRU',
                ];

  useEffect(() => {
    const randomVideoId = videoIds[Math.floor(Math.random() * videoIds.length)];
    setVideoId(randomVideoId);
  }, []);

  return (
    <div className="App">
      <YouTube className='video'videoId={videoId} />
      <YouTube className='video'videoId={videoId} />
      <YouTube className='video'videoId={videoId} />
      <YouTube className='video'videoId={videoId} />
    </div>
  );
}

export default App;