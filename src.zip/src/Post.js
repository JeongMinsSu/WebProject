import React from 'react';

const Post = ({ title, content, username }) => {
  return (
    <div>
      <h2>{title}</h2>
      <h5>{username}</h5>
      <hr />
      <p>{content}</p>
      
    </div>
  );
};

export default Post;