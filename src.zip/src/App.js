import React from 'react';
import { BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import MainPage from './MainPage';
import AgeOne from './Page/AgeOne.js';
import AgeTwo from './Page/AgeTwo.js';
import AgeThree from './Page/AgeThree.js';
import Writing from './Writing.js';
import WritingInfo from './WritingInfo.js'
import WritingInfo2 from './WritingInfo2.js'
import WritingInfo3 from './WritingInfo3.js'
import './App.css';


const App = () => {
  
  return (
    
    <div>
      
    <Router>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="/write" element={<Writing />} />
        <Route path="/AgeOne/:category" element={<AgeOne />} />
        <Route path="/AgeTwo/:category" element={<AgeTwo />} />
        <Route path="/AgeThree/:category" element={<AgeThree />} />
        <Route path="/post/:title" element={<WritingInfo/>}/>
        <Route path="/post2/:title2" element={<WritingInfo2/>}/>
        <Route path="/post3/:title3" element={<WritingInfo3/>}/>
      </Routes>
    </Router>
    
    </div>
    
    
  );
};


export default App;