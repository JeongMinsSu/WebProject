import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import Post from './Post.js';
import './App.css';

function WritingInfo3() {
  // const [selectedPostId, setSelectedPostId] = useState(null);
  // const {Title} = useParams();
  const [loading,setLoading] = useState({});
  const [post3,setPost3] = useState({});
  const getPost3 = async () => {
    const resp = await axios.get("http://localhost:3001/api/todo3");
    setPost3(resp.data);
    setLoading(false);

  };
  useEffect(()=> {
    getPost3();
  },[]);
  
  
// const selectedPost = post.find((todo)=> );

  const {title3} = useParams();
  const currentPost = Array.isArray(post3) && post3.find((item) => item.title3 === title3);
  return (
    <div className='background'>
      {loading ? (
        <h1>Loading...</h1>
      ):(

        <div className='section'>
          {currentPost && (
          <div className='inside'key={currentPost.id}>
            <h2>제목: {currentPost.title3}</h2>
            <hr></hr>
            <h4>작성자: {currentPost.username3}</h4>  
            <p> 내용: {currentPost.content3}</p>
          <div className='backTo'>
            <Link to='/'><input type='button' value='돌아가기'/></Link>
          </div>
        </div>
    )}
        </div> 
      )}
    </div>
    );
}

export default WritingInfo3;