import React from 'react';

const Footer = () => {
  return (
    <footer>
      <hr/>
      Copyright 2023. 웹응용 4조 All pictures cannot be copied without permission. 
    </footer>
  );
};

export default Footer;